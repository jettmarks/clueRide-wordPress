Redify is the child theme of Rambo theme. Give it a try you will love it

=== Description ===
In this version you will get the theme Red color variant.

=== Support ===
For any ideas, support and feedback you can access the theme forum.

== Version ==
= 400000.0.3 =
1. Add Setting Option panel To Customizer.
= 400000.0.2 =
1. Added Theme URI
2. Added theme name as a prefix in the script name handlers.
400000.0.1 Released

The CSS, XHTML and design is released under GPL:
Banner Image
https://unsplash.com/photos/lZlfHGqx44Q

Product Image
https://pixabay.com/en/photographer-tourist-snapshot-407068/
https://pixabay.com/en/woman-girl-people-female-hand-792162/

